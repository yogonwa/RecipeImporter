import json
import logging
import os
from typing import Dict, Any, Optional, List
from urllib.parse import urlparse
from recipe_scrapers import scrape_me
from recipe_scrapers._exceptions import WebsiteNotImplementedError, NoSchemaFoundInWildMode
from notion_client import Client
from notion_client.errors import APIResponseError

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Notion configuration
NOTION_API_KEY = os.environ.get('NOTION_API_KEY')
NOTION_DATABASE_ID = os.environ.get('NOTION_DATABASE_ID')

# Initialize Notion client
notion = Client(auth=NOTION_API_KEY) if NOTION_API_KEY else None

def is_valid_url(url: str) -> bool:
    """
    Check if the provided URL is valid and uses HTTP/HTTPS.
    """
    try:
        result = urlparse(url)
        return all([result.scheme in ['http', 'https'], result.netloc])
    except Exception:
        return False

def validate_request(event: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """
    Validate the incoming webhook request.
    Returns dict with url and page_id if valid, None if invalid.
    """
    try:
        # Check if we have a body
        if 'body' not in event:
            logger.error("No body found in event")
            return None
        
        # Parse body
        body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        
        # Check for required fields
        url = body.get('url')
        page_id = body.get('page_id')  # Optional for direct scraping

        if not url or not isinstance(url, str):
            logger.error("No valid URL found in request body")
            return None
        
        # Validate URL format
        if not is_valid_url(url):
            logger.error(f"Invalid URL format: {url}")
            return None
        
        return {
            'url': url,
            'page_id': page_id
        }
    except json.JSONDecodeError:
        logger.error("Failed to parse JSON body")
        return None
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return None

def scrape_recipe(url: str) -> Dict[str, Any]:
    """
    Scrape recipe data from the provided URL.
    Returns structured recipe data.
    """
    try:
        scraper = scrape_me(url)
        
        recipe_data = {
            "title": scraper.title(),
            "total_time": scraper.total_time(),
            "prep_time": scraper.prep_time() if hasattr(scraper, 'prep_time') else None,
            "yields": scraper.yields(),
            "ingredients": scraper.ingredients(),
            "instructions": scraper.instructions().split('. ') if scraper.instructions() else [],
            "image": scraper.image(),
            "host": scraper.host(),
            "nutrients": scraper.nutrients(),
            "cuisine": scraper.cuisine() if hasattr(scraper, 'cuisine') else None,
            "category": scraper.category() if hasattr(scraper, 'category') else None,
            "url": url
        }
        
        # Filter out None values
        filtered_data = {k: v for k, v in recipe_data.items() if v is not None}
        
        # Ensure we have at least some basic recipe data
        if not filtered_data.get('title') or not filtered_data.get('ingredients'):
            raise NoSchemaFoundInWildMode("Could not extract basic recipe information")
        
        return filtered_data
    
    except WebsiteNotImplementedError:
        logger.warning(f"Website not implemented for URL: {url}")
        raise
    except NoSchemaFoundInWildMode:
        logger.warning(f"No recipe schema found for URL: {url}")
        raise
    except Exception as e:
        logger.error(f"Scraping error: {str(e)}")
        raise

def create_notion_blocks(recipe_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Create Notion blocks from recipe data.
    """
    blocks = []
    
    # Add ingredients section
    if recipe_data.get('ingredients'):
        blocks.extend([
            {"object": "block", "type": "heading_2", "heading_2": {"text": [{"text": {"content": "Ingredients"}}]}},
            *[
                {"object": "block", "type": "bulleted_list_item", "bulleted_list_item": {"text": [{"text": {"content": ingredient}}]}}
                for ingredient in recipe_data['ingredients']
            ]
        ])
    
    # Add instructions section
    if recipe_data.get('instructions'):
        blocks.extend([
            {"object": "block", "type": "heading_2", "heading_2": {"text": [{"text": {"content": "Instructions"}}]}},
            *[
                {"object": "block", "type": "numbered_list_item", "numbered_list_item": {"text": [{"text": {"content": step.strip()}}]}}
                for step in recipe_data['instructions']
            ]
        ])
    
    return blocks

def update_notion_page(page_id: str, recipe_data: Dict[str, Any]) -> None:
    """
    Update a Notion page with recipe data.
    """
    if not notion:
        raise ValueError("Notion client not initialized. Please set NOTION_API_KEY environment variable.")

    # Create properties object
    properties = {
        "Title": {"title": [{"text": {"content": recipe_data["title"]}}]},
        "Source": {"rich_text": [{"text": {"content": recipe_data["host"]}}]},
    }

    # Add optional properties
    if recipe_data.get('total_time'):
        properties["Cooking Time"] = {"number": recipe_data["total_time"]}
    if recipe_data.get('prep_time'):
        properties["Prep Time"] = {"number": recipe_data["prep_time"]}
    if recipe_data.get('cuisine'):
        properties["Tags"] = {"multi_select": [{"name": tag} for tag in recipe_data["cuisine"]]}
    if recipe_data.get('category'):
        properties["Type"] = {"select": {"name": recipe_data["category"]}}

    # Update the page
    notion.pages.update(
        page_id=page_id,
        properties=properties,
        children=create_notion_blocks(recipe_data)
    )

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler function.
    """
    try:
        # Log the incoming event
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Validate the request
        request_data = validate_request(event)
        if not request_data:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({
                    'error': 'Invalid request. Please provide a valid URL in the request body.'
                })
            }
        
        # Scrape the recipe
        recipe_data = scrape_recipe(request_data['url'])
        
        # If page_id is provided, update Notion
        if request_data.get('page_id'):
            try:
                update_notion_page(request_data['page_id'], recipe_data)
                success_message = "Recipe successfully scraped and added to Notion"
            except APIResponseError as e:
                return {
                    'statusCode': 422,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({
                        'error': 'Notion API Error',
                        'message': str(e),
                        'data': recipe_data  # Still return the scraped data
                    })
                }
        else:
            success_message = "Recipe successfully scraped"
        
        # Return success response
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'success': True,
                'message': success_message,
                'data': recipe_data
            })
        }
        
    except (WebsiteNotImplementedError, NoSchemaFoundInWildMode) as e:
        return {
            'statusCode': 422,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'error': str(e),
                'message': 'Unable to extract recipe from the provided URL'
            })
        }
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }
