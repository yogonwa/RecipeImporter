import json
import logging
from typing import Dict, Any, Optional
from urllib.parse import urlparse
from recipe_scrapers import scrape_me
from recipe_scrapers._exceptions import WebsiteNotImplementedError, NoSchemaFoundInWildMode

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def is_valid_url(url: str) -> bool:
    """
    Check if the provided URL is valid and uses HTTP/HTTPS.
    """
    try:
        result = urlparse(url)
        return all([result.scheme in ['http', 'https'], result.netloc])
    except Exception:
        return False

def validate_request(event: Dict[str, Any]) -> Optional[str]:
    """
    Validate the incoming webhook request.
    Returns URL if valid, None if invalid.
    """
    try:
        # Check if we have a body
        if 'body' not in event:
            logger.error("No body found in event")
            return None
        
        # Parse body
        body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        
        # Check for URL
        url = body.get('url')
        if not url or not isinstance(url, str):
            logger.error("No valid URL found in request body")
            return None
        
        # Validate URL format
        if not is_valid_url(url):
            logger.error(f"Invalid URL format: {url}")
            return None
        
        return url
    except json.JSONDecodeError:
        logger.error("Failed to parse JSON body")
        return None
    except Exception as e:
        logger.error(f"Validation error: {str(e)}")
        return None

def scrape_recipe(url: str) -> Dict[str, Any]:
    """
    Scrape recipe data from the provided URL.
    Returns structured recipe data.
    """
    try:
        scraper = scrape_me(url)
        
        recipe_data = {
            "title": scraper.title(),
            "total_time": scraper.total_time(),
            "yields": scraper.yields(),
            "ingredients": scraper.ingredients(),
            "instructions": scraper.instructions(),
            "image": scraper.image(),
            "host": scraper.host(),
            "nutrients": scraper.nutrients(),
            "url": url  # Add source URL to the response
        }
        
        # Filter out None values
        filtered_data = {k: v for k, v in recipe_data.items() if v is not None}
        
        # Ensure we have at least some basic recipe data
        if not filtered_data.get('title') or not filtered_data.get('ingredients'):
            raise NoSchemaFoundInWildMode("Could not extract basic recipe information")
        
        return filtered_data
    
    except WebsiteNotImplementedError:
        logger.warning(f"Website not implemented for URL: {url}")
        raise
    except NoSchemaFoundInWildMode:
        logger.warning(f"No recipe schema found for URL: {url}")
        raise
    except Exception as e:
        logger.error(f"Scraping error: {str(e)}")
        raise

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler function.
    """
    try:
        # Log the incoming event
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Validate the request
        url = validate_request(event)
        if not url:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({
                    'error': 'Invalid request. Please provide a valid URL in the request body.'
                })
            }
        
        # Scrape the recipe
        recipe_data = scrape_recipe(url)
        
        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'success': True,
                'data': recipe_data
            })
        }
        
    except (WebsiteNotImplementedError, NoSchemaFoundInWildMode) as e:
        return {
            'statusCode': 422,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Unable to extract recipe from the provided URL'
            })
        }
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }
